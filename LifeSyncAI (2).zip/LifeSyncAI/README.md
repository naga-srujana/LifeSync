# 🚀 LifeSync AI – Unified Personal Management Platform

> A full-stack Java Spring Boot web application for managing your entire life in one place.
> Built as a student portfolio project with modern SaaS-style UI.

---

## 📸 Features

| Module | What It Does |
|---|---|
| 📋 Job Tracker | Track applications, interviews, offers, rejections |
| 🛍️ Orders | Amazon, Flipkart, Swiggy orders with delivery & warranty tracking |
| ❤️ Health | Appointments, medicines, vaccinations, BMI calculator |
| 💳 Subscriptions | Netflix, Spotify, ChatGPT renewal alerts |
| 💰 Expenses | Category-wise spending with pie & bar charts |
| ✅ Tasks | Priority tasks with overdue alerts |
| 📁 Documents | Secure vault for resume, Aadhaar, certificates |
| 🎓 Learning | Course progress, hours studied, certifications |
| ✈️ Travel | Trip planning, budget tracker, ticket uploads |
| 🔍 Global Search | Search across all modules from one bar |
| 🌙 Dark Mode | Full dark/light theme toggle |
| 🤖 AI Chat (UI) | Ready for OpenAI integration |

---

## 🛠️ Tech Stack

- **Backend:** Java 17 + Spring Boot 3.2
- **Security:** Spring Security + BCrypt
- **Database:** SQLite (via Hibernate JPA)
- **Frontend:** Thymeleaf + Bootstrap 5 + Chart.js
- **Icons:** Bootstrap Icons
- **Build:** Maven

---

## ⚡ Quick Start

### Prerequisites

Make sure you have installed:
- Java 17 or higher → `java -version`
- Maven 3.8+ → `mvn -version`
- Git (optional)

---

### 1. Clone or Download the Project

```bash
git clone https://github.com/yourusername/LifeSyncAI.git
cd LifeSyncAI
```

Or download the ZIP and extract it.

---

### 2. Build the Project

```bash
mvn clean install -DskipTests
```

---

### 3. Run the Application

```bash
mvn spring-boot:run
```

You should see:
```
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
...
Started LifeSyncApplication in X.XXX seconds
```

---

### 4. Open in Browser

```
http://localhost:8080
```

---

### 5. Demo Login

The app auto-creates a demo user on first run:

| Field    | Value                |
|----------|----------------------|
| Email    | demo@lifesync.com    |
| Password | demo123              |

Or register your own account at `/register`.

---

## 📂 Project Structure

```
LifeSyncAI/
├── src/main/java/com/lifesync/
│   ├── LifeSyncApplication.java       ← Entry point
│   ├── config/
│   │   ├── SecurityConfig.java        ← Spring Security + BCrypt
│   │   └── WebConfig.java             ← Static resource config
│   ├── controller/                    ← All route handlers (11 controllers)
│   ├── model/                         ← JPA Entity classes (10 models)
│   ├── repository/                    ← Spring Data JPA repos (10)
│   ├── service/                       ← Business logic (10 services)
│   └── util/
│       ├── DataInitializer.java       ← Sample data seeder
│       └── FileStorageUtil.java       ← File upload helper
│
└── src/main/resources/
    ├── templates/                     ← Thymeleaf HTML pages
    │   ├── auth/                      ← login.html, register.html
    │   ├── dashboard.html
    │   ├── jobs/, orders/, health/
    │   ├── subscriptions/, expenses/
    │   ├── tasks/, documents/
    │   ├── learning/, travel/
    │   └── search-results.html
    ├── static/
    │   ├── css/style.css              ← Complete custom styles
    │   ├── js/main.js                 ← Dark mode, sidebar, charts
    │   └── uploads/                   ← Uploaded files stored here
    └── application.properties         ← App configuration
```

---

## 🔧 Configuration

`src/main/resources/application.properties`:

```properties
# Server
server.port=8080

# SQLite Database (auto-created in project root)
spring.datasource.url=jdbc:sqlite:lifesync.db
spring.datasource.driver-class-name=org.sqlite.JDBC
spring.jpa.database-platform=org.hibernate.community.dialect.SQLiteDialect
spring.jpa.hibernate.ddl-auto=update

# File Upload (max 10MB)
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB
app.upload.dir=src/main/resources/static/uploads
```

---

## 🎯 All Routes

| URL | Page |
|-----|------|
| `/login` | Login |
| `/register` | Register |
| `/dashboard` | Main Dashboard |
| `/jobs` | Job Tracker |
| `/orders` | Order Tracker |
| `/health` | Health Module |
| `/subscriptions` | Subscriptions |
| `/expenses` | Expense Tracker |
| `/tasks` | Tasks & Reminders |
| `/documents` | Document Vault |
| `/learning` | Learning Goals |
| `/travel` | Travel Bookings |
| `/search?query=X` | Global Search |

---

## 📊 Dashboard Charts

All charts powered by **Chart.js 4.x**:

- 🍩 Expense breakdown doughnut chart (by category)
- 🍩 Job application status doughnut chart
- 📊 Expense bar chart (by category)
- ⭕ Learning progress ring gauge

---

## 🔒 Security

- Passwords hashed with **BCryptPasswordEncoder**
- All routes protected (except `/login`, `/register`)
- CSRF tokens on all forms (Thymeleaf auto-injects)
- User data isolation — each user sees only their own data

---

## 🌙 Dark Mode

Click the moon icon (🌙) in the top-right navbar to toggle dark/light mode.
Preference is saved in `localStorage` and persists across sessions.

---

## 💡 Future Enhancements

- [ ] OpenAI API integration for the AI Assistant chat
- [ ] Email reminders for subscription renewals
- [ ] OCR receipt scanning (Tess4J)
- [ ] Export data to PDF/Excel
- [ ] Mobile app (Android/iOS)
- [ ] Google Calendar sync

---

## 🧑‍💻 Developer Info

**Built with ❤️ as a student portfolio project.**

- Stack: Java 17 · Spring Boot 3.2 · SQLite · Bootstrap 5
- Author: [Your Name]
- GitHub: [your-github-link]

---

## 📝 License

This project is open source and free to use for educational purposes.

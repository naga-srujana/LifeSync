package com.lifesync.controller;

import com.lifesync.model.LearningGoal;
import com.lifesync.model.User;
import com.lifesync.service.LearningService;
import com.lifesync.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequestMapping("/learning")
@RequiredArgsConstructor
public class LearningController {

    private final LearningService learningService;
    private final UserService userService;

    @GetMapping
    public String listLearning(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("goals", learningService.getAllByUser(user));
        model.addAttribute("avgProgress", learningService.getAverageProgress(user));
        model.addAttribute("certifiedCount", learningService.getAllByUser(user).stream().filter(LearningGoal::getCertified).count());
        return "learning/list";
    }

    @GetMapping("/new")
    public String newLearningForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("goal", new LearningGoal());
        model.addAttribute("isEdit", false);
        return "learning/form";
    }

    @PostMapping("/save")
    public String saveLearning(@AuthenticationPrincipal UserDetails userDetails,
                               @RequestParam String courseName,
                               @RequestParam String skillCategory,
                               @RequestParam Integer progressPercent,
                               @RequestParam Double hoursStudied,
                               @RequestParam(required = false) Double targetHours,
                               @RequestParam(required = false) Boolean certified,
                               @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate completionDate,
                               @RequestParam(required = false) String notes,
                               @RequestParam(required = false) Long id,
                               RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        LearningGoal goal = id != null ? learningService.getById(id).orElse(new LearningGoal()) : new LearningGoal();
        goal.setCourseName(courseName);
        goal.setSkillCategory(skillCategory);
        goal.setProgressPercent(progressPercent);
        goal.setHoursStudied(hoursStudied);
        goal.setTargetHours(targetHours);
        goal.setCertified(certified != null && certified);
        goal.setCompletionDate(completionDate);
        goal.setNotes(notes);
        goal.setUser(user);
        learningService.save(goal);
        redirectAttributes.addFlashAttribute("success", "Learning goal saved!");
        return "redirect:/learning";
    }

    @GetMapping("/edit/{id}")
    public String editLearning(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        LearningGoal goal = learningService.getById(id).orElseThrow();
        if (!goal.getUser().getId().equals(user.getId())) return "redirect:/learning";
        model.addAttribute("user", user);
        model.addAttribute("goal", goal);
        model.addAttribute("isEdit", true);
        return "learning/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteLearning(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        LearningGoal goal = learningService.getById(id).orElseThrow();
        if (goal.getUser().getId().equals(user.getId())) learningService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Goal deleted!");
        return "redirect:/learning";
    }
}

package com.lifesync.controller;

import com.lifesync.model.Expense;
import com.lifesync.model.User;
import com.lifesync.service.ExpenseService;
import com.lifesync.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/expenses")
@RequiredArgsConstructor
public class ExpenseController {

    private final ExpenseService expenseService;
    private final UserService userService;

    @GetMapping
    public String listExpenses(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("expenses", expenseService.getAllByUser(user));
        model.addAttribute("monthlyTotal", expenseService.getMonthlyTotal(user));

        List<Object[]> breakdown = expenseService.getCategoryBreakdown(user);
        List<String> labels = new ArrayList<>();
        List<Double> data = new ArrayList<>();
        for (Object[] row : breakdown) {
            labels.add((String) row[0]);
            data.add(((Number) row[1]).doubleValue());
        }
        model.addAttribute("catLabels", labels);
        model.addAttribute("catData", data);
        return "expenses/list";
    }

    @GetMapping("/new")
    public String newExpenseForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("expense", new Expense());
        model.addAttribute("isEdit", false);
        return "expenses/form";
    }

    @PostMapping("/save")
    public String saveExpense(@AuthenticationPrincipal UserDetails userDetails,
                              @RequestParam String title,
                              @RequestParam Double amount,
                              @RequestParam String category,
                              @RequestParam String paymentMethod,
                              @RequestParam(required = false) String notes,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate expenseDate,
                              @RequestParam(required = false) Long id,
                              RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Expense expense = id != null ? expenseService.getById(id).orElse(new Expense()) : new Expense();
        expense.setTitle(title);
        expense.setAmount(amount);
        expense.setCategory(category);
        expense.setPaymentMethod(paymentMethod);
        expense.setNotes(notes);
        expense.setExpenseDate(expenseDate);
        expense.setUser(user);
        expenseService.save(expense);
        redirectAttributes.addFlashAttribute("success", "Expense saved successfully!");
        return "redirect:/expenses";
    }

    @GetMapping("/edit/{id}")
    public String editExpense(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Expense expense = expenseService.getById(id).orElseThrow();
        if (!expense.getUser().getId().equals(user.getId())) return "redirect:/expenses";
        model.addAttribute("user", user);
        model.addAttribute("expense", expense);
        model.addAttribute("isEdit", true);
        return "expenses/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteExpense(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Expense expense = expenseService.getById(id).orElseThrow();
        if (expense.getUser().getId().equals(user.getId())) expenseService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Expense deleted!");
        return "redirect:/expenses";
    }
}

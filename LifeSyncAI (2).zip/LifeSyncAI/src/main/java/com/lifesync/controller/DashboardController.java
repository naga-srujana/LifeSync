package com.lifesync.controller;

import com.lifesync.model.*;
import com.lifesync.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final UserService userService;
    private final JobService jobService;
    private final OrderService orderService;
    private final ExpenseService expenseService;
    private final TaskService taskService;
    private final SubscriptionService subscriptionService;
    private final HealthService healthService;
    private final LearningService learningService;
    private final TravelService travelService;
    private final DocumentService documentService;

    @GetMapping("/")
    public String root() {
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());

        // Stats for widgets
        model.addAttribute("user", user);
        model.addAttribute("totalExpenses", expenseService.getMonthlyTotal(user));
        model.addAttribute("pendingTasks", taskService.countPending(user));
        model.addAttribute("activeJobs", jobService.countActiveApplications(user));
        model.addAttribute("monthlySubs", subscriptionService.getTotalMonthlyCost(user));
        model.addAttribute("recentOrders", orderService.getRecentOrders(user));
        model.addAttribute("upcomingAppointments", healthService.getUpcomingAppointments(user));
        model.addAttribute("upcomingTrips", travelService.getUpcomingTrips(user));
        model.addAttribute("learningProgress", learningService.getAverageProgress(user));
        model.addAttribute("upcomingRenewals", subscriptionService.getUpcomingRenewals(user));
        model.addAttribute("overdueTasks", taskService.getOverdueTasks(user));

        // Chart data — expense by category
        List<Object[]> catBreakdown = expenseService.getCategoryBreakdown(user);
        List<String> catLabels = new ArrayList<>();
        List<Double> catData = new ArrayList<>();
        for (Object[] row : catBreakdown) {
            catLabels.add((String) row[0]);
            catData.add(((Number) row[1]).doubleValue());
        }
        model.addAttribute("expenseCatLabels", catLabels);
        model.addAttribute("expenseCatData", catData);

        // Job status chart data
        model.addAttribute("jobApplied", jobService.getJobsByStatus(user, JobApplication.JobStatus.APPLIED).size());
        model.addAttribute("jobInterview", jobService.getJobsByStatus(user, JobApplication.JobStatus.INTERVIEW_SCHEDULED).size());
        model.addAttribute("jobOffer", jobService.getJobsByStatus(user, JobApplication.JobStatus.OFFER_RECEIVED).size());
        model.addAttribute("jobRejected", jobService.getJobsByStatus(user, JobApplication.JobStatus.REJECTED).size());

        return "dashboard";
    }

    @GetMapping("/search")
    public String globalSearch(@RequestParam String query,
                               @AuthenticationPrincipal UserDetails userDetails,
                               Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("query", query);
        model.addAttribute("jobs", jobService.searchJobs(user, query));
        model.addAttribute("expenses", expenseService.search(user, query));
        model.addAttribute("tasks", taskService.search(user, query));
        model.addAttribute("subscriptions", subscriptionService.search(user, query));
        model.addAttribute("documents", documentService.search(user, query));
        model.addAttribute("orders", orderService.searchOrders(user, query));
        return "search-results";
    }
}

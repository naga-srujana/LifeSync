package com.lifesync.controller;

import com.lifesync.model.Subscription;
import com.lifesync.model.User;
import com.lifesync.service.SubscriptionService;
import com.lifesync.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequestMapping("/subscriptions")
@RequiredArgsConstructor
public class SubscriptionController {

    private final SubscriptionService subscriptionService;
    private final UserService userService;

    @GetMapping
    public String listSubscriptions(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("subscriptions", subscriptionService.getAllByUser(user));
        model.addAttribute("monthlyCost", subscriptionService.getTotalMonthlyCost(user));
        model.addAttribute("upcomingRenewals", subscriptionService.getUpcomingRenewals(user));
        model.addAttribute("activeCount", subscriptionService.getActiveSubscriptions(user).size());
        return "subscriptions/list";
    }

    @GetMapping("/new")
    public String newSubForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("subscription", new Subscription());
        model.addAttribute("isEdit", false);
        return "subscriptions/form";
    }

    @PostMapping("/save")
    public String saveSub(@AuthenticationPrincipal UserDetails userDetails,
                          @RequestParam String name,
                          @RequestParam Double cost,
                          @RequestParam String billingCycle,
                          @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate renewalDate,
                          @RequestParam String category,
                          @RequestParam String status,
                          @RequestParam(required = false) Long id,
                          RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Subscription sub = id != null ? subscriptionService.getById(id).orElse(new Subscription()) : new Subscription();
        sub.setName(name);
        sub.setCost(cost);
        sub.setBillingCycle(billingCycle);
        sub.setRenewalDate(renewalDate);
        sub.setCategory(category);
        sub.setStatus(status);
        sub.setUser(user);
        subscriptionService.save(sub);
        redirectAttributes.addFlashAttribute("success", "Subscription saved!");
        return "redirect:/subscriptions";
    }

    @GetMapping("/edit/{id}")
    public String editSub(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Subscription sub = subscriptionService.getById(id).orElseThrow();
        if (!sub.getUser().getId().equals(user.getId())) return "redirect:/subscriptions";
        model.addAttribute("user", user);
        model.addAttribute("subscription", sub);
        model.addAttribute("isEdit", true);
        return "subscriptions/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteSub(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Subscription sub = subscriptionService.getById(id).orElseThrow();
        if (sub.getUser().getId().equals(user.getId())) subscriptionService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Subscription deleted!");
        return "redirect:/subscriptions";
    }
}

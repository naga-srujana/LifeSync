package com.lifesync.controller;

import com.lifesync.model.Order;
import com.lifesync.model.User;
import com.lifesync.service.OrderService;
import com.lifesync.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequestMapping("/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final UserService userService;

    @GetMapping
    public String listOrders(@AuthenticationPrincipal UserDetails userDetails,
                             @RequestParam(required = false) String platform,
                             @RequestParam(required = false) String status,
                             Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);

        if (platform != null && !platform.isEmpty()) {
            model.addAttribute("orders", orderService.filterByPlatform(user, platform));
        } else if (status != null && !status.isEmpty()) {
            model.addAttribute("orders", orderService.filterByStatus(user, status));
        } else {
            model.addAttribute("orders", orderService.getAllOrdersByUser(user));
        }
        return "orders/list";
    }

    @GetMapping("/new")
    public String newOrderForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("order", new Order());
        model.addAttribute("isEdit", false);
        return "orders/form";
    }

    @PostMapping("/save")
    public String saveOrder(@AuthenticationPrincipal UserDetails userDetails,
                            @RequestParam String productName,
                            @RequestParam String platform,
                            @RequestParam(required = false) Double price,
                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate orderDate,
                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate deliveryDate,
                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate returnDeadline,
                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate warrantyExpiry,
                            @RequestParam String status,
                            @RequestParam(required = false) String notes,
                            @RequestParam(required = false) Long id,
                            RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Order order = id != null ? orderService.getOrderById(id).orElse(new Order()) : new Order();
        order.setProductName(productName);
        order.setPlatform(platform);
        order.setPrice(price);
        order.setOrderDate(orderDate);
        order.setDeliveryDate(deliveryDate);
        order.setReturnDeadline(returnDeadline);
        order.setWarrantyExpiry(warrantyExpiry);
        order.setStatus(status);
        order.setNotes(notes);
        order.setUser(user);
        orderService.saveOrder(order);
        redirectAttributes.addFlashAttribute("success", "Order saved!");
        return "redirect:/orders";
    }

    @GetMapping("/edit/{id}")
    public String editOrder(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Order order = orderService.getOrderById(id).orElseThrow();
        if (!order.getUser().getId().equals(user.getId())) return "redirect:/orders";
        model.addAttribute("user", user);
        model.addAttribute("order", order);
        model.addAttribute("isEdit", true);
        return "orders/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteOrder(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Order order = orderService.getOrderById(id).orElseThrow();
        if (order.getUser().getId().equals(user.getId())) orderService.deleteOrder(id);
        redirectAttributes.addFlashAttribute("success", "Order deleted!");
        return "redirect:/orders";
    }
}

package com.lifesync.controller;

import com.lifesync.model.TravelBooking;
import com.lifesync.model.User;
import com.lifesync.service.TravelService;
import com.lifesync.service.UserService;
import com.lifesync.util.FileStorageUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.time.LocalDate;

@Controller
@RequestMapping("/travel")
@RequiredArgsConstructor
public class TravelController {

    private final TravelService travelService;
    private final UserService userService;
    private final FileStorageUtil fileStorageUtil;

    @GetMapping
    public String listTravel(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("bookings", travelService.getAllByUser(user));
        model.addAttribute("upcomingTrips", travelService.getUpcomingTrips(user));
        return "travel/list";
    }

    @GetMapping("/new")
    public String newTravelForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("booking", new TravelBooking());
        model.addAttribute("isEdit", false);
        return "travel/form";
    }

    @PostMapping("/save")
    public String saveTravel(@AuthenticationPrincipal UserDetails userDetails,
                             @RequestParam String tripName,
                             @RequestParam String destination,
                             @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate,
                             @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate returnDate,
                             @RequestParam(required = false) String hotelName,
                             @RequestParam(required = false) String hotelAddress,
                             @RequestParam(required = false) Double budget,
                             @RequestParam(required = false) Double amountSpent,
                             @RequestParam(required = false) String notes,
                             @RequestParam(required = false) MultipartFile ticketFile,
                             @RequestParam(required = false) Long id,
                             RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        TravelBooking booking = id != null ? travelService.getById(id).orElse(new TravelBooking()) : new TravelBooking();
        booking.setTripName(tripName);
        booking.setDestination(destination);
        booking.setTravelDate(travelDate);
        booking.setReturnDate(returnDate);
        booking.setHotelName(hotelName);
        booking.setHotelAddress(hotelAddress);
        booking.setBudget(budget);
        booking.setAmountSpent(amountSpent);
        booking.setNotes(notes);
        booking.setUser(user);

        if (ticketFile != null && !ticketFile.isEmpty()) {
            try {
                String filePath = fileStorageUtil.storeFile(ticketFile, "travel");
                booking.setTicketFilePath(filePath);
            } catch (IOException e) {
                redirectAttributes.addFlashAttribute("error", "Ticket upload failed.");
            }
        }

        travelService.save(booking);
        redirectAttributes.addFlashAttribute("success", "Trip saved!");
        return "redirect:/travel";
    }

    @GetMapping("/edit/{id}")
    public String editTravel(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        TravelBooking booking = travelService.getById(id).orElseThrow();
        if (!booking.getUser().getId().equals(user.getId())) return "redirect:/travel";
        model.addAttribute("user", user);
        model.addAttribute("booking", booking);
        model.addAttribute("isEdit", true);
        return "travel/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteTravel(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        TravelBooking booking = travelService.getById(id).orElseThrow();
        if (booking.getUser().getId().equals(user.getId())) travelService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Trip deleted!");
        return "redirect:/travel";
    }
}

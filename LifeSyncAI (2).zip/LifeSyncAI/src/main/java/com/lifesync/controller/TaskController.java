package com.lifesync.controller;

import com.lifesync.model.Task;
import com.lifesync.model.User;
import com.lifesync.service.TaskService;
import com.lifesync.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequestMapping("/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;
    private final UserService userService;

    @GetMapping
    public String listTasks(@AuthenticationPrincipal UserDetails userDetails,
                            @RequestParam(required = false) String filter, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);

        if ("pending".equals(filter)) {
            model.addAttribute("tasks", taskService.getAllByUser(user).stream().filter(t -> !t.getCompleted()).toList());
        } else if ("completed".equals(filter)) {
            model.addAttribute("tasks", taskService.getAllByUser(user).stream().filter(Task::getCompleted).toList());
        } else if ("overdue".equals(filter)) {
            model.addAttribute("tasks", taskService.getOverdueTasks(user));
        } else {
            model.addAttribute("tasks", taskService.getAllByUser(user));
        }

        model.addAttribute("pendingCount", taskService.countPending(user));
        model.addAttribute("overdueTasks", taskService.getOverdueTasks(user));
        model.addAttribute("filter", filter);
        return "tasks/list";
    }

    @GetMapping("/new")
    public String newTaskForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("task", new Task());
        model.addAttribute("priorities", Task.Priority.values());
        model.addAttribute("isEdit", false);
        return "tasks/form";
    }

    @PostMapping("/save")
    public String saveTask(@AuthenticationPrincipal UserDetails userDetails,
                           @RequestParam String title,
                           @RequestParam(required = false) String description,
                           @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dueDate,
                           @RequestParam String priority,
                           @RequestParam(required = false) Long id,
                           RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Task task = id != null ? taskService.getById(id).orElse(new Task()) : new Task();
        task.setTitle(title);
        task.setDescription(description);
        task.setDueDate(dueDate);
        task.setPriority(Task.Priority.valueOf(priority));
        task.setUser(user);
        if (id == null) task.setCompleted(false);
        taskService.save(task);
        redirectAttributes.addFlashAttribute("success", "Task saved!");
        return "redirect:/tasks";
    }

    @GetMapping("/toggle/{id}")
    public String toggleTask(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Task task = taskService.getById(id).orElseThrow();
        if (task.getUser().getId().equals(user.getId())) {
            task.setCompleted(!task.getCompleted());
            taskService.save(task);
        }
        return "redirect:/tasks";
    }

    @GetMapping("/edit/{id}")
    public String editTask(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Task task = taskService.getById(id).orElseThrow();
        if (!task.getUser().getId().equals(user.getId())) return "redirect:/tasks";
        model.addAttribute("user", user);
        model.addAttribute("task", task);
        model.addAttribute("priorities", Task.Priority.values());
        model.addAttribute("isEdit", true);
        return "tasks/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteTask(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Task task = taskService.getById(id).orElseThrow();
        if (task.getUser().getId().equals(user.getId())) taskService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Task deleted!");
        return "redirect:/tasks";
    }
}

package com.lifesync.controller;

import com.lifesync.model.Document;
import com.lifesync.model.User;
import com.lifesync.service.DocumentService;
import com.lifesync.service.UserService;
import com.lifesync.util.FileStorageUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.time.LocalDate;

@Controller
@RequestMapping("/documents")
@RequiredArgsConstructor
public class DocumentController {

    private final DocumentService documentService;
    private final UserService userService;
    private final FileStorageUtil fileStorageUtil;

    @GetMapping
    public String listDocuments(@AuthenticationPrincipal UserDetails userDetails,
                                @RequestParam(required = false) String category,
                                @RequestParam(required = false) String search,
                                Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);

        if (search != null && !search.isEmpty()) {
            model.addAttribute("documents", documentService.search(user, search));
        } else if (category != null && !category.isEmpty()) {
            model.addAttribute("documents", documentService.getByCategory(user, category));
            model.addAttribute("filterCategory", category);
        } else {
            model.addAttribute("documents", documentService.getAllByUser(user));
        }
        return "documents/list";
    }

    @GetMapping("/new")
    public String newDocForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        return "documents/form";
    }

    @PostMapping("/upload")
    public String uploadDocument(@AuthenticationPrincipal UserDetails userDetails,
                                 @RequestParam MultipartFile file,
                                 @RequestParam String category,
                                 RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());

        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Please select a file.");
            return "redirect:/documents/new";
        }

        try {
            String filePath = fileStorageUtil.storeFile(file, "documents");
            Document doc = new Document();
            doc.setOriginalName(file.getOriginalFilename());
            doc.setFileName(file.getOriginalFilename());
            doc.setCategory(category);
            doc.setFilePath(filePath);
            doc.setFileSize(file.getSize());
            doc.setFileType(file.getContentType());
            doc.setUploadDate(LocalDate.now());
            doc.setUser(user);
            documentService.save(doc);
            redirectAttributes.addFlashAttribute("success", "Document uploaded successfully!");
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Upload failed: " + e.getMessage());
        }
        return "redirect:/documents";
    }

    @GetMapping("/delete/{id}")
    public String deleteDocument(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Document doc = documentService.getById(id).orElseThrow();
        if (doc.getUser().getId().equals(user.getId())) {
            fileStorageUtil.deleteFile(doc.getFilePath());
            documentService.delete(id);
        }
        redirectAttributes.addFlashAttribute("success", "Document deleted!");
        return "redirect:/documents";
    }
}

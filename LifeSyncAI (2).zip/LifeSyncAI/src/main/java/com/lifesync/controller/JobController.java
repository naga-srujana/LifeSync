package com.lifesync.controller;

import com.lifesync.model.JobApplication;
import com.lifesync.model.User;
import com.lifesync.service.JobService;
import com.lifesync.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;
    private final UserService userService;

    @GetMapping
    public String listJobs(@AuthenticationPrincipal UserDetails userDetails,
                           @RequestParam(required = false) String status,
                           Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);

        if (status != null && !status.isEmpty()) {
            try {
                JobApplication.JobStatus jobStatus = JobApplication.JobStatus.valueOf(status);
                model.addAttribute("jobs", jobService.getJobsByStatus(user, jobStatus));
                model.addAttribute("filterStatus", status);
            } catch (IllegalArgumentException e) {
                model.addAttribute("jobs", jobService.getAllJobsByUser(user));
            }
        } else {
            model.addAttribute("jobs", jobService.getAllJobsByUser(user));
        }

        model.addAttribute("statuses", JobApplication.JobStatus.values());
        model.addAttribute("activeJobs", jobService.countActiveApplications(user));
        return "jobs/list";
    }

    @GetMapping("/new")
    public String newJobForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("job", new JobApplication());
        model.addAttribute("statuses", JobApplication.JobStatus.values());
        model.addAttribute("isEdit", false);
        return "jobs/form";
    }

    @PostMapping("/save")
    public String saveJob(@AuthenticationPrincipal UserDetails userDetails,
                          @RequestParam String companyName,
                          @RequestParam String role,
                          @RequestParam(required = false) String packageOffered,
                          @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate applicationDate,
                          @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate interviewDate,
                          @RequestParam(required = false) String notes,
                          @RequestParam(required = false) String resumeUsed,
                          @RequestParam String status,
                          @RequestParam(required = false) Long id,
                          RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());

        JobApplication job = id != null ? jobService.getJobById(id).orElse(new JobApplication()) : new JobApplication();
        job.setCompanyName(companyName);
        job.setRole(role);
        job.setPackageOffered(packageOffered);
        job.setApplicationDate(applicationDate);
        job.setInterviewDate(interviewDate);
        job.setNotes(notes);
        job.setResumeUsed(resumeUsed);
        job.setStatus(JobApplication.JobStatus.valueOf(status));
        job.setUser(user);

        jobService.saveJob(job);
        redirectAttributes.addFlashAttribute("success", "Job application saved successfully!");
        return "redirect:/jobs";
    }

    @GetMapping("/edit/{id}")
    public String editJob(@PathVariable Long id,
                          @AuthenticationPrincipal UserDetails userDetails,
                          Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        JobApplication job = jobService.getJobById(id).orElseThrow();
        if (!job.getUser().getId().equals(user.getId())) return "redirect:/jobs";
        model.addAttribute("user", user);
        model.addAttribute("job", job);
        model.addAttribute("statuses", JobApplication.JobStatus.values());
        model.addAttribute("isEdit", true);
        return "jobs/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteJob(@PathVariable Long id,
                            @AuthenticationPrincipal UserDetails userDetails,
                            RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        JobApplication job = jobService.getJobById(id).orElseThrow();
        if (job.getUser().getId().equals(user.getId())) {
            jobService.deleteJob(id);
            redirectAttributes.addFlashAttribute("success", "Job deleted successfully!");
        }
        return "redirect:/jobs";
    }
}

package com.lifesync.controller;

import com.lifesync.model.HealthRecord;
import com.lifesync.model.User;
import com.lifesync.service.HealthService;
import com.lifesync.service.UserService;
import com.lifesync.util.FileStorageUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.time.LocalDate;

@Controller
@RequestMapping("/health")
@RequiredArgsConstructor
public class HealthController {

    private final HealthService healthService;
    private final UserService userService;
    private final FileStorageUtil fileStorageUtil;

    @GetMapping
    public String listHealth(@AuthenticationPrincipal UserDetails userDetails,
                             @RequestParam(required = false) String type, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);

        if (type != null && !type.isEmpty()) {
            model.addAttribute("records", healthService.getByType(user, type));
            model.addAttribute("filterType", type);
        } else {
            model.addAttribute("records", healthService.getAllHealthByUser(user));
        }

        model.addAttribute("upcomingAppointments", healthService.getUpcomingAppointments(user));
        return "health/list";
    }

    @GetMapping("/new")
    public String newHealthForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        model.addAttribute("user", user);
        model.addAttribute("record", new HealthRecord());
        model.addAttribute("isEdit", false);
        return "health/form";
    }

    @PostMapping("/save")
    public String saveHealth(@AuthenticationPrincipal UserDetails userDetails,
                             @RequestParam String type,
                             @RequestParam String title,
                             @RequestParam(required = false) String description,
                             @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                             @RequestParam(required = false) String doctorName,
                             @RequestParam(required = false) String hospitalName,
                             @RequestParam(required = false) Double weight,
                             @RequestParam(required = false) Double waterIntake,
                             @RequestParam(required = false) MultipartFile reportFile,
                             @RequestParam(required = false) Long id,
                             RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        HealthRecord record = id != null ? healthService.getHealthById(id).orElse(new HealthRecord()) : new HealthRecord();
        record.setType(type);
        record.setTitle(title);
        record.setDescription(description);
        record.setDate(date);
        record.setDoctorName(doctorName);
        record.setHospitalName(hospitalName);
        record.setWeight(weight);
        record.setWaterIntake(waterIntake);
        record.setUser(user);

        if (reportFile != null && !reportFile.isEmpty()) {
            try {
                String filePath = fileStorageUtil.storeFile(reportFile, "health");
                record.setReportFilePath(filePath);
            } catch (IOException e) {
                redirectAttributes.addFlashAttribute("error", "File upload failed.");
            }
        }

        healthService.saveHealth(record);
        redirectAttributes.addFlashAttribute("success", "Health record saved!");
        return "redirect:/health";
    }

    @GetMapping("/edit/{id}")
    public String editHealth(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        HealthRecord record = healthService.getHealthById(id).orElseThrow();
        if (!record.getUser().getId().equals(user.getId())) return "redirect:/health";
        model.addAttribute("user", user);
        model.addAttribute("record", record);
        model.addAttribute("isEdit", true);
        return "health/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteHealth(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        HealthRecord record = healthService.getHealthById(id).orElseThrow();
        if (record.getUser().getId().equals(user.getId())) healthService.deleteHealth(id);
        redirectAttributes.addFlashAttribute("success", "Health record deleted!");
        return "redirect:/health";
    }
}

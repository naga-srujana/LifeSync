package com.lifesync.util;

import com.lifesync.model.*;
import com.lifesync.repository.*;
import com.lifesync.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserService userService;
    private final JobRepository jobRepository;
    private final ExpenseRepository expenseRepository;
    private final TaskRepository taskRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final HealthRepository healthRepository;
    private final LearningRepository learningRepository;
    private final TravelRepository travelRepository;
    private final OrderRepository orderRepository;

    @Override
    public void run(String... args) {
        // Create demo user if not exists
        if (!userService.emailExists("demo@lifesync.com")) {
            User user = userService.registerUser("Demo User", "demo@lifesync.com", "demo123");
            log.info("Demo user created: demo@lifesync.com / demo123");
            seedData(user);
        }
    }

    private void seedData(User user) {
        // Jobs
        JobApplication job1 = new JobApplication();
        job1.setCompanyName("Google"); job1.setRole("Software Engineer"); job1.setPackageOffered("₹45 LPA");
        job1.setApplicationDate(LocalDate.now().minusDays(10)); job1.setStatus(JobApplication.JobStatus.INTERVIEW_SCHEDULED);
        job1.setNotes("Round 2 scheduled"); job1.setUser(user);
        jobRepository.save(job1);

        JobApplication job2 = new JobApplication();
        job2.setCompanyName("Amazon"); job2.setRole("Backend Developer"); job2.setPackageOffered("₹38 LPA");
        job2.setApplicationDate(LocalDate.now().minusDays(5)); job2.setStatus(JobApplication.JobStatus.OA_CLEARED);
        job2.setUser(user);
        jobRepository.save(job2);

        JobApplication job3 = new JobApplication();
        job3.setCompanyName("Flipkart"); job3.setRole("Full Stack Developer"); job3.setPackageOffered("₹30 LPA");
        job3.setApplicationDate(LocalDate.now().minusDays(15)); job3.setStatus(JobApplication.JobStatus.APPLIED);
        job3.setUser(user);
        jobRepository.save(job3);

        // Expenses
        saveExpense(user, "Swiggy Dinner", 450.0, "Food", "UPI", LocalDate.now().minusDays(1));
        saveExpense(user, "Metro Pass", 200.0, "Travel", "Card", LocalDate.now().minusDays(2));
        saveExpense(user, "Books", 850.0, "Education", "UPI", LocalDate.now().minusDays(3));
        saveExpense(user, "Electricity Bill", 1200.0, "Bills", "NetBanking", LocalDate.now().minusDays(4));
        saveExpense(user, "Medicines", 350.0, "Healthcare", "Cash", LocalDate.now().minusDays(5));

        // Tasks
        saveTask(user, "Prepare for Google Interview", "Study DSA topics", LocalDate.now().plusDays(3), Task.Priority.HIGH, false);
        saveTask(user, "Submit assignment", "React project submission", LocalDate.now().plusDays(1), Task.Priority.HIGH, false);
        saveTask(user, "Call doctor", "Schedule annual checkup", LocalDate.now().plusDays(7), Task.Priority.MEDIUM, false);
        saveTask(user, "Renew Passport", "Visit Passport Seva Kendra", LocalDate.now().plusDays(30), Task.Priority.LOW, false);
        saveTask(user, "Buy groceries", "Weekend shopping", LocalDate.now().minusDays(1), Task.Priority.MEDIUM, true);

        // Subscriptions
        saveSub(user, "Netflix", 649.0, "Monthly", LocalDate.now().plusDays(15), "Entertainment", "Active");
        saveSub(user, "Spotify", 119.0, "Monthly", LocalDate.now().plusDays(8), "Entertainment", "Active");
        saveSub(user, "ChatGPT Plus", 1700.0, "Monthly", LocalDate.now().plusDays(20), "Productivity", "Active");
        saveSub(user, "Coursera Plus", 4999.0, "Yearly", LocalDate.now().plusDays(120), "Education", "Active");

        // Health
        HealthRecord h1 = new HealthRecord();
        h1.setType("Appointment"); h1.setTitle("Annual Health Checkup");
        h1.setDoctorName("Dr. Sharma"); h1.setHospitalName("City Hospital");
        h1.setDate(LocalDate.now().plusDays(5)); h1.setUser(user);
        healthRepository.save(h1);

        HealthRecord h2 = new HealthRecord();
        h2.setType("Vaccination"); h2.setTitle("Flu Shot");
        h2.setDate(LocalDate.now().minusDays(30)); h2.setUser(user);
        healthRepository.save(h2);

        // Learning
        saveLearning(user, "Spring Boot Masterclass", "Programming", 65, 28.5, 40.0, false);
        saveLearning(user, "AWS Cloud Practitioner", "Programming", 40, 15.0, 35.0, false);
        saveLearning(user, "UI/UX Design Fundamentals", "Design", 90, 45.0, 50.0, true);

        // Travel
        TravelBooking trip = new TravelBooking();
        trip.setTripName("Goa Trip"); trip.setDestination("Goa, India");
        trip.setTravelDate(LocalDate.now().plusDays(45)); trip.setReturnDate(LocalDate.now().plusDays(49));
        trip.setHotelName("The Leela Goa"); trip.setBudget(25000.0); trip.setAmountSpent(5000.0);
        trip.setNotes("Flight booked. Hotel confirmation pending."); trip.setUser(user);
        travelRepository.save(trip);

        // Orders
        saveOrder(user, "MacBook Pro M3", "Amazon", 185000.0, LocalDate.now().minusDays(3), "Ordered",
                LocalDate.now().plusDays(4), LocalDate.now().plusDays(10));
        saveOrder(user, "Nike Air Max", "Myntra", 8999.0, LocalDate.now().minusDays(7), "Delivered",
                LocalDate.now().minusDays(2), LocalDate.now().plusDays(7));

        log.info("Sample data seeded successfully!");
    }

    private void saveExpense(User user, String title, Double amount, String category, String method, LocalDate date) {
        Expense e = new Expense();
        e.setTitle(title); e.setAmount(amount); e.setCategory(category);
        e.setPaymentMethod(method); e.setExpenseDate(date); e.setUser(user);
        expenseRepository.save(e);
    }

    private void saveTask(User user, String title, String desc, LocalDate due, Task.Priority priority, Boolean completed) {
        Task t = new Task();
        t.setTitle(title); t.setDescription(desc); t.setDueDate(due);
        t.setPriority(priority); t.setCompleted(completed); t.setUser(user);
        taskRepository.save(t);
    }

    private void saveSub(User user, String name, Double cost, String cycle, LocalDate renewal, String category, String status) {
        Subscription s = new Subscription();
        s.setName(name); s.setCost(cost); s.setBillingCycle(cycle);
        s.setRenewalDate(renewal); s.setCategory(category); s.setStatus(status); s.setUser(user);
        subscriptionRepository.save(s);
    }

    private void saveLearning(User user, String course, String category, int progress, double hours, double target, boolean certified) {
        LearningGoal g = new LearningGoal();
        g.setCourseName(course); g.setSkillCategory(category); g.setProgressPercent(progress);
        g.setHoursStudied(hours); g.setTargetHours(target); g.setCertified(certified); g.setUser(user);
        learningRepository.save(g);
    }

    private void saveOrder(User user, String product, String platform, Double price, LocalDate orderDate,
                           String status, LocalDate delivery, LocalDate returnDl) {
        Order o = new Order();
        o.setProductName(product); o.setPlatform(platform); o.setPrice(price);
        o.setOrderDate(orderDate); o.setStatus(status); o.setDeliveryDate(delivery);
        o.setReturnDeadline(returnDl); o.setUser(user);
        orderRepository.save(o);
    }
}

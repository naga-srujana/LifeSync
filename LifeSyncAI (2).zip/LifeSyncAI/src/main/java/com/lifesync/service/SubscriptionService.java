package com.lifesync.service;

import com.lifesync.model.Subscription;
import com.lifesync.model.User;
import com.lifesync.repository.SubscriptionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SubscriptionService {
    private final SubscriptionRepository subscriptionRepository;

    public List<Subscription> getAllByUser(User user) { return subscriptionRepository.findByUserOrderByRenewalDateAsc(user); }
    public Optional<Subscription> getById(Long id) { return subscriptionRepository.findById(id); }
    public Subscription save(Subscription sub) { return subscriptionRepository.save(sub); }
    public void delete(Long id) { subscriptionRepository.deleteById(id); }

    public Double getTotalMonthlyCost(User user) {
        Double cost = subscriptionRepository.sumMonthlyCostByUser(user);
        return cost != null ? cost : 0.0;
    }

    public List<Subscription> getUpcomingRenewals(User user) {
        return subscriptionRepository.findByUserAndRenewalDateBetween(
                user, LocalDate.now(), LocalDate.now().plusDays(30));
    }

    public List<Subscription> getActiveSubscriptions(User user) {
        return subscriptionRepository.findByUserAndStatus(user, "Active");
    }

    public List<Subscription> search(User user, String keyword) {
        return subscriptionRepository.findByUserAndNameContainingIgnoreCase(user, keyword);
    }
}

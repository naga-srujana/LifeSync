package com.lifesync.service;

import com.lifesync.model.TravelBooking;
import com.lifesync.model.User;
import com.lifesync.repository.TravelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TravelService {
    private final TravelRepository travelRepository;

    public List<TravelBooking> getAllByUser(User user) { return travelRepository.findByUserOrderByTravelDateAsc(user); }
    public Optional<TravelBooking> getById(Long id) { return travelRepository.findById(id); }
    public TravelBooking save(TravelBooking booking) { return travelRepository.save(booking); }
    public void delete(Long id) { travelRepository.deleteById(id); }

    public List<TravelBooking> getUpcomingTrips(User user) {
        return travelRepository.findByUserAndTravelDateAfterOrderByTravelDate(user, LocalDate.now());
    }

    public List<TravelBooking> search(User user, String keyword) {
        return travelRepository.findByUserAndDestinationContainingIgnoreCase(user, keyword);
    }
}

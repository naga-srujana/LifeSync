package com.lifesync.service;

import com.lifesync.model.Task;
import com.lifesync.model.User;
import com.lifesync.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TaskService {
    private final TaskRepository taskRepository;

    public List<Task> getAllByUser(User user) { return taskRepository.findByUserOrderByDueDateAsc(user); }
    public Optional<Task> getById(Long id) { return taskRepository.findById(id); }
    public Task save(Task task) { return taskRepository.save(task); }
    public void delete(Long id) { taskRepository.deleteById(id); }

    public long countPending(User user) { return taskRepository.countByUserAndCompleted(user, false); }

    public List<Task> getOverdueTasks(User user) {
        return taskRepository.findByUserAndDueDateBeforeAndCompleted(user, LocalDate.now(), false);
    }

    public List<Task> getByPriority(User user, Task.Priority priority) {
        return taskRepository.findByUserAndPriority(user, priority);
    }

    public List<Task> search(User user, String keyword) {
        return taskRepository.findByUserAndTitleContainingIgnoreCase(user, keyword);
    }
}

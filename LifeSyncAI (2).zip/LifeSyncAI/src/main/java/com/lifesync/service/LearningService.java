package com.lifesync.service;

import com.lifesync.model.LearningGoal;
import com.lifesync.model.User;
import com.lifesync.repository.LearningRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LearningService {
    private final LearningRepository learningRepository;

    public List<LearningGoal> getAllByUser(User user) { return learningRepository.findByUserOrderByProgressPercentDesc(user); }
    public Optional<LearningGoal> getById(Long id) { return learningRepository.findById(id); }
    public LearningGoal save(LearningGoal goal) { return learningRepository.save(goal); }
    public void delete(Long id) { learningRepository.deleteById(id); }

    public Double getAverageProgress(User user) {
        Double avg = learningRepository.avgProgressByUser(user);
        return avg != null ? avg : 0.0;
    }

    public List<LearningGoal> getByCategory(User user, String category) {
        return learningRepository.findByUserAndSkillCategory(user, category);
    }
}

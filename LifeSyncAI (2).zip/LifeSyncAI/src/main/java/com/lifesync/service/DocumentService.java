package com.lifesync.service;

import com.lifesync.model.Document;
import com.lifesync.model.User;
import com.lifesync.repository.DocumentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class DocumentService {
    private final DocumentRepository documentRepository;

    public List<Document> getAllByUser(User user) { return documentRepository.findByUserOrderByUploadDateDesc(user); }
    public Optional<Document> getById(Long id) { return documentRepository.findById(id); }
    public Document save(Document doc) { return documentRepository.save(doc); }
    public void delete(Long id) { documentRepository.deleteById(id); }
    public List<Document> getByCategory(User user, String category) { return documentRepository.findByUserAndCategory(user, category); }
    public List<Document> search(User user, String keyword) { return documentRepository.findByUserAndOriginalNameContainingIgnoreCase(user, keyword); }
}

package com.lifesync.service;

import com.lifesync.model.HealthRecord;
import com.lifesync.model.User;
import com.lifesync.repository.HealthRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class HealthService {
    private final HealthRepository healthRepository;

    public List<HealthRecord> getAllHealthByUser(User user) { return healthRepository.findByUserOrderByDateDesc(user); }
    public Optional<HealthRecord> getHealthById(Long id) { return healthRepository.findById(id); }
    public HealthRecord saveHealth(HealthRecord record) { return healthRepository.save(record); }
    public void deleteHealth(Long id) { healthRepository.deleteById(id); }
    public List<HealthRecord> getByType(User user, String type) { return healthRepository.findByUserAndType(user, type); }
    public List<HealthRecord> getUpcomingAppointments(User user) {
        return healthRepository.findByUserAndDateAfterOrderByDate(user, LocalDate.now());
    }
}

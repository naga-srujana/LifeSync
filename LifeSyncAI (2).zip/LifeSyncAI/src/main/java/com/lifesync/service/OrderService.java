package com.lifesync.service;

import com.lifesync.model.Order;
import com.lifesync.model.User;
import com.lifesync.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;

    public List<Order> getAllOrdersByUser(User user) { return orderRepository.findByUserOrderByOrderDateDesc(user); }
    public Optional<Order> getOrderById(Long id) { return orderRepository.findById(id); }
    public Order saveOrder(Order order) { return orderRepository.save(order); }
    public void deleteOrder(Long id) { orderRepository.deleteById(id); }
    public List<Order> getRecentOrders(User user) { return orderRepository.findTop5ByUserOrderByOrderDateDesc(user); }
    public List<Order> searchOrders(User user, String keyword) { return orderRepository.findByUserAndProductNameContainingIgnoreCase(user, keyword); }
    public List<Order> filterByPlatform(User user, String platform) { return orderRepository.findByUserAndPlatform(user, platform); }
    public List<Order> filterByStatus(User user, String status) { return orderRepository.findByUserAndStatus(user, status); }
}

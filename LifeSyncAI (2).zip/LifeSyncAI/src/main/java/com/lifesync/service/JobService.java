package com.lifesync.service;

import com.lifesync.model.JobApplication;
import com.lifesync.model.User;
import com.lifesync.repository.JobRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final JobRepository jobRepository;

    public List<JobApplication> getAllJobsByUser(User user) {
        return jobRepository.findByUserOrderByApplicationDateDesc(user);
    }

    public List<JobApplication> getJobsByStatus(User user, JobApplication.JobStatus status) {
        return jobRepository.findByUserAndStatus(user, status);
    }

    public Optional<JobApplication> getJobById(Long id) {
        return jobRepository.findById(id);
    }

    public JobApplication saveJob(JobApplication job) {
        return jobRepository.save(job);
    }

    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }

    public long countActiveApplications(User user) {
        return jobRepository.countByUserAndStatus(user, JobApplication.JobStatus.APPLIED)
             + jobRepository.countByUserAndStatus(user, JobApplication.JobStatus.INTERVIEW_SCHEDULED)
             + jobRepository.countByUserAndStatus(user, JobApplication.JobStatus.OA_CLEARED)
             + jobRepository.countByUserAndStatus(user, JobApplication.JobStatus.HR_ROUND);
    }

    public List<JobApplication> searchJobs(User user, String keyword) {
        return jobRepository.findByUserAndCompanyNameContainingIgnoreCase(user, keyword);
    }
}

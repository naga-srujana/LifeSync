package com.lifesync.service;

import com.lifesync.model.Expense;
import com.lifesync.model.User;
import com.lifesync.repository.ExpenseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ExpenseService {
    private final ExpenseRepository expenseRepository;

    public List<Expense> getAllByUser(User user) { return expenseRepository.findByUserOrderByExpenseDateDesc(user); }
    public Optional<Expense> getById(Long id) { return expenseRepository.findById(id); }
    public Expense save(Expense expense) { return expenseRepository.save(expense); }
    public void delete(Long id) { expenseRepository.deleteById(id); }

    public Double getMonthlyTotal(User user) {
        LocalDate start = LocalDate.now().withDayOfMonth(1);
        LocalDate end = LocalDate.now();
        Double total = expenseRepository.sumAmountByUserAndDateBetween(user, start, end);
        return total != null ? total : 0.0;
    }

    public List<Object[]> getCategoryBreakdown(User user) {
        return expenseRepository.sumByCategory(user);
    }

    public List<Expense> getByDateRange(User user, LocalDate start, LocalDate end) {
        return expenseRepository.findByUserAndExpenseDateBetweenOrderByExpenseDateDesc(user, start, end);
    }

    public List<Expense> search(User user, String keyword) {
        return expenseRepository.findByUserAndTitleContainingIgnoreCase(user, keyword);
    }
}

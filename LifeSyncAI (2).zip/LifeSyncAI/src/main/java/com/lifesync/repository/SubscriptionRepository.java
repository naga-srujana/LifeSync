package com.lifesync.repository;

import com.lifesync.model.Subscription;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    List<Subscription> findByUserOrderByRenewalDateAsc(User user);
    List<Subscription> findByUserAndStatus(User user, String status);
    List<Subscription> findByUserAndRenewalDateBetween(User user, LocalDate start, LocalDate end);

    @Query("SELECT SUM(s.cost) FROM Subscription s WHERE s.user = ?1 AND s.status = 'Active' AND s.billingCycle = 'Monthly'")
    Double sumMonthlyCostByUser(User user);

    List<Subscription> findByUserAndNameContainingIgnoreCase(User user, String keyword);
}

package com.lifesync.repository;

import com.lifesync.model.LearningGoal;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LearningRepository extends JpaRepository<LearningGoal, Long> {
    List<LearningGoal> findByUserOrderByProgressPercentDesc(User user);
    List<LearningGoal> findByUserAndSkillCategory(User user, String category);
    List<LearningGoal> findByUserAndCertified(User user, Boolean certified);

    @Query("SELECT AVG(l.progressPercent) FROM LearningGoal l WHERE l.user = ?1")
    Double avgProgressByUser(User user);
}

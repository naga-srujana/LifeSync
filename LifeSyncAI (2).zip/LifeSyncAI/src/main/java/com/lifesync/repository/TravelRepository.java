package com.lifesync.repository;

import com.lifesync.model.TravelBooking;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface TravelRepository extends JpaRepository<TravelBooking, Long> {
    List<TravelBooking> findByUserOrderByTravelDateAsc(User user);
    List<TravelBooking> findByUserAndTravelDateAfterOrderByTravelDate(User user, LocalDate date);
    List<TravelBooking> findByUserAndDestinationContainingIgnoreCase(User user, String keyword);
}

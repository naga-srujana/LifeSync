package com.lifesync.repository;

import com.lifesync.model.Task;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByUserOrderByDueDateAsc(User user);
    List<Task> findByUserAndCompleted(User user, Boolean completed);
    List<Task> findByUserAndPriority(User user, Task.Priority priority);
    List<Task> findByUserAndDueDateBeforeAndCompleted(User user, LocalDate date, Boolean completed);
    long countByUserAndCompleted(User user, Boolean completed);
    List<Task> findByUserAndTitleContainingIgnoreCase(User user, String keyword);
}

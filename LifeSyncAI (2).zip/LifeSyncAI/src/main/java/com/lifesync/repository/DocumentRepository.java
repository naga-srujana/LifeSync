package com.lifesync.repository;

import com.lifesync.model.Document;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DocumentRepository extends JpaRepository<Document, Long> {
    List<Document> findByUserOrderByUploadDateDesc(User user);
    List<Document> findByUserAndCategory(User user, String category);
    List<Document> findByUserAndOriginalNameContainingIgnoreCase(User user, String keyword);
}

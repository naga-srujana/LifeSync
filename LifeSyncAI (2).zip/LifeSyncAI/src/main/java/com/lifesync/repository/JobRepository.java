package com.lifesync.repository;

import com.lifesync.model.JobApplication;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<JobApplication, Long> {
    List<JobApplication> findByUserOrderByApplicationDateDesc(User user);
    List<JobApplication> findByUserAndStatus(User user, JobApplication.JobStatus status);
    long countByUserAndStatus(User user, JobApplication.JobStatus status);
    List<JobApplication> findByUserAndCompanyNameContainingIgnoreCase(User user, String keyword);
}

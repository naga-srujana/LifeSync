package com.lifesync.repository;

import com.lifesync.model.Expense;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    List<Expense> findByUserOrderByExpenseDateDesc(User user);
    List<Expense> findByUserAndExpenseDateBetweenOrderByExpenseDateDesc(User user, LocalDate start, LocalDate end);
    List<Expense> findByUserAndCategory(User user, String category);

    @Query("SELECT SUM(e.amount) FROM Expense e WHERE e.user = ?1 AND e.expenseDate BETWEEN ?2 AND ?3")
    Double sumAmountByUserAndDateBetween(User user, LocalDate start, LocalDate end);

    @Query("SELECT e.category, SUM(e.amount) FROM Expense e WHERE e.user = ?1 GROUP BY e.category")
    List<Object[]> sumByCategory(User user);

    List<Expense> findByUserAndTitleContainingIgnoreCase(User user, String keyword);
}

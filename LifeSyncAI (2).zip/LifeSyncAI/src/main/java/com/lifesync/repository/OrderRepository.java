package com.lifesync.repository;

import com.lifesync.model.Order;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserOrderByOrderDateDesc(User user);
    List<Order> findByUserAndPlatform(User user, String platform);
    List<Order> findByUserAndStatus(User user, String status);
    List<Order> findByUserAndProductNameContainingIgnoreCase(User user, String keyword);
    List<Order> findTop5ByUserOrderByOrderDateDesc(User user);
}

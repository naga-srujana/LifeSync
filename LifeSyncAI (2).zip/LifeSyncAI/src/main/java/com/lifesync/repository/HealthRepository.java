package com.lifesync.repository;

import com.lifesync.model.HealthRecord;
import com.lifesync.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface HealthRepository extends JpaRepository<HealthRecord, Long> {
    List<HealthRecord> findByUserOrderByDateDesc(User user);
    List<HealthRecord> findByUserAndType(User user, String type);
    List<HealthRecord> findByUserAndDateAfterOrderByDate(User user, LocalDate date);
}

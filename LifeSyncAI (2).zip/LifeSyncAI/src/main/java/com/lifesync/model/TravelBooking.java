package com.lifesync.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "travel_bookings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TravelBooking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String tripName;

    private String destination;

    private LocalDate travelDate;

    private LocalDate returnDate;

    private String hotelName;

    private String hotelAddress;

    private Double budget;

    private Double amountSpent;

    @Column(length = 1000)
    private String notes;

    private String ticketFilePath;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}

package com.lifesync.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String productName;

    private String platform; // Amazon, Flipkart, Myntra, Swiggy, Zomato, Other

    private Double price;

    private LocalDate orderDate;

    private LocalDate deliveryDate;

    private LocalDate returnDeadline;

    private LocalDate warrantyExpiry;

    private String status; // Ordered, Shipped, Delivered, Returned, Cancelled

    @Column(length = 500)
    private String notes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}

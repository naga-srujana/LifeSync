package com.lifesync.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "job_applications")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JobApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String companyName;

    @NotBlank
    private String role;

    private String packageOffered;

    private LocalDate applicationDate;

    private LocalDate interviewDate;

    @Column(length = 1000)
    private String notes;

    private String resumeUsed;

    @Enumerated(EnumType.STRING)
    private JobStatus status = JobStatus.APPLIED;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public enum JobStatus {
        APPLIED, OA_CLEARED, INTERVIEW_SCHEDULED, HR_ROUND, REJECTED, OFFER_RECEIVED
    }
}

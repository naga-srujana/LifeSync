/* ============================================================
   LifeSync AI – main.js
   Dark Mode, Sidebar Toggle, UI Interactions
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

    // ── Dark Mode ──────────────────────────────────────────
    const darkToggle = document.getElementById('darkModeToggle');
    const darkIcon   = document.getElementById('darkModeIcon');
    const savedTheme = localStorage.getItem('lifesync-theme');

    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        if (darkIcon) { darkIcon.className = 'bi bi-sun-fill'; }
    }

    if (darkToggle) {
        darkToggle.addEventListener('click', function () {
            document.body.classList.toggle('dark-mode');
            const isDark = document.body.classList.contains('dark-mode');
            localStorage.setItem('lifesync-theme', isDark ? 'dark' : 'light');
            if (darkIcon) {
                darkIcon.className = isDark ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
            }
        });
    }

    // ── Sidebar Toggle ─────────────────────────────────────
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar       = document.getElementById('sidebar');
    const mainContent   = document.getElementById('mainContent');

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function () {
            if (window.innerWidth <= 768) {
                sidebar.classList.toggle('show');
            } else {
                sidebar.classList.toggle('collapsed');
                if (sidebar.classList.contains('collapsed')) {
                    sidebar.style.width = '70px';
                    mainContent.style.marginLeft = '70px';
                    sidebar.querySelectorAll('.nav-item span, .sidebar-user-info, .sidebar-brand span, .nav-section-title')
                        .forEach(el => el.style.display = 'none');
                } else {
                    sidebar.style.width = '';
                    mainContent.style.marginLeft = '';
                    sidebar.querySelectorAll('.nav-item span, .sidebar-user-info, .sidebar-brand span, .nav-section-title')
                        .forEach(el => el.style.display = '');
                }
            }
        });

        // Close sidebar on outside click (mobile)
        document.addEventListener('click', function (e) {
            if (window.innerWidth <= 768 &&
                sidebar.classList.contains('show') &&
                !sidebar.contains(e.target) &&
                !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });
    }

    // ── Auto-dismiss alerts ────────────────────────────────
    document.querySelectorAll('.alert:not(.alert-permanent)').forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 4000);
    });

    // ── Confirm delete links ────────────────────────────────
    document.querySelectorAll('a[href*="/delete/"]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            if (!confirm('Are you sure you want to delete this? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // ── Active nav highlight ───────────────────────────────
    const currentPath = window.location.pathname;
    document.querySelectorAll('.nav-item').forEach(function (item) {
        const href = item.getAttribute('href');
        if (href && currentPath.startsWith(href) && href !== '/') {
            item.classList.add('active');
        }
    });

    // ── Tooltip init ───────────────────────────────────────
    const tooltipEls = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltipEls.forEach(el => new bootstrap.Tooltip(el));

    // ── Form input animation ───────────────────────────────
    document.querySelectorAll('.form-control, .form-select').forEach(function (input) {
        if (input.value) input.closest('.input-modern')?.classList.add('has-value');
        input.addEventListener('focus', function () {
            this.closest('.input-modern')?.classList.add('focused');
        });
        input.addEventListener('blur', function () {
            this.closest('.input-modern')?.classList.remove('focused');
            if (this.value) this.closest('.input-modern')?.classList.add('has-value');
            else this.closest('.input-modern')?.classList.remove('has-value');
        });
    });

    // ── Set today's date as default for date inputs ────────
    const today = new Date().toISOString().split('T')[0];
    document.querySelectorAll('input[type="date"]').forEach(function (input) {
        if (!input.value && !input.hasAttribute('data-no-default')) {
            input.value = today;
        }
    });

    // ── Table row click to highlight ──────────────────────
    document.querySelectorAll('.table-modern tbody tr').forEach(function (row) {
        row.style.cursor = 'pointer';
        row.addEventListener('click', function (e) {
            if (e.target.closest('a, button')) return;
            document.querySelectorAll('.table-modern tbody tr').forEach(r => r.classList.remove('table-active'));
            this.classList.add('table-active');
        });
    });

    // ── Counter animation for stat values ─────────────────
    document.querySelectorAll('.stat-value').forEach(function (el) {
        const text = el.textContent.trim();
        const num  = parseFloat(text.replace(/[^0-9.]/g, ''));
        if (!isNaN(num) && num > 0 && num < 100000) {
            const prefix = text.match(/^[^0-9]*/)?.[0] || '';
            const suffix = text.match(/[^0-9.]+$/)?.[0] || '';
            let start = 0;
            const duration = 800;
            const step = num / (duration / 16);
            const timer = setInterval(function () {
                start += step;
                if (start >= num) {
                    start = num;
                    clearInterval(timer);
                }
                el.textContent = prefix + Math.floor(start).toLocaleString('en-IN') + suffix;
            }, 16);
        }
    });

    // ── Search input on mobile ─────────────────────────────
    const mobileSearchBtn = document.getElementById('mobileSearchBtn');
    if (mobileSearchBtn) {
        mobileSearchBtn.addEventListener('click', function () {
            const form = document.querySelector('form[action*="/search"]');
            if (form) form.querySelector('input')?.focus();
        });
    }

    // ── Progress bar animation ─────────────────────────────
    document.querySelectorAll('.progress-bar').forEach(function (bar) {
        const target = bar.style.width;
        bar.style.width = '0%';
        setTimeout(function () {
            bar.style.transition = 'width 1s ease-in-out';
            bar.style.width = target;
        }, 200);
    });

    // ── Keyboard shortcut: '/' to focus search ─────────────
    document.addEventListener('keydown', function (e) {
        if (e.key === '/' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)) {
            e.preventDefault();
            const searchInput = document.querySelector('input[name="query"]');
            if (searchInput) searchInput.focus();
        }
        // Escape to close sidebar on mobile
        if (e.key === 'Escape' && sidebar) sidebar.classList.remove('show');
    });

    // ── Sticky table header scroll shadow ─────────────────
    const tableContainers = document.querySelectorAll('.table-responsive');
    tableContainers.forEach(function (tc) {
        tc.addEventListener('scroll', function () {
            const thead = tc.querySelector('thead');
            if (thead) {
                thead.style.boxShadow = tc.scrollTop > 0
                    ? '0 2px 8px rgba(0,0,0,0.1)' : 'none';
            }
        });
    });

    console.log('%c LifeSync AI ✅ Loaded', 'color:#6366f1;font-weight:bold;font-size:14px;');
});

// ── Password Toggle (Auth pages) ──────────────────────────
function togglePassword(id, btn) {
    const input = document.getElementById(id);
    const icon  = btn.querySelector('i');
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    icon.className = input.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
}

// ── BMI Calculator (Health page) ──────────────────────────
function calcBMI() {
    const w = parseFloat(document.getElementById('bmiWeight')?.value);
    const h = parseFloat(document.getElementById('bmiHeight')?.value) / 100;
    const resultEl = document.getElementById('bmiResult');
    if (!w || !h || h <= 0 || !resultEl) return;
    const bmi = (w / (h * h)).toFixed(1);
    const cat = bmi < 18.5 ? 'Underweight 🔵'
              : bmi < 25   ? 'Normal Weight ✅'
              : bmi < 30   ? 'Overweight ⚠️'
              : 'Obese 🔴';
    const cls = bmi < 18.5 ? 'info'
              : bmi < 25   ? 'success'
              : bmi < 30   ? 'warning'
              : 'danger';
    resultEl.innerHTML =
        `<div class="alert alert-${cls} py-2 mb-0 fw-semibold">
            BMI: <strong>${bmi}</strong> — ${cat}
         </div>`;
}

// ── Learning Progress Preview ──────────────────────────────
function updateProgressBar(val) {
    const bar = document.getElementById('progressPreview');
    if (bar) bar.style.width = Math.min(Math.max(val, 0), 100) + '%';
}
